const { getHomeData } = require('../controllers/homeController'); 
const db = require('../config/db');

// Burlar (Mock) la base de datos
jest.mock('../config/db', () => ({
    query: jest.fn()
}));

describe('Controlador: homeController', () => {
    let req, res;

    beforeEach(() => {
        jest.clearAllMocks();
        
        // Simular que el usuario con ID 1 está haciendo la petición
        req = { user: { id: 1 } };
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    describe('Método: getHomeData', () => {
        
        it('CP-01: Debería retornar datos del locker sin recordatorio si faltan más de 24 hrs', async () => {
          
            const fechaLejana = new Date(Date.now() + (48 * 60 * 60 * 1000)); 
            
            db.query.mockResolvedValueOnce({ 
                rows: [{ number: 'A-01', building: 'Edificio 1', fecha_vencimiento: fechaLejana }] 
            });
         
            db.query.mockResolvedValueOnce({ 
                rows: [{ id: 1, action: 'abierto remotamente', time: '2026-06-14 10:00' }] 
            });

            await getHomeData(req, res);

            expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
                locker: expect.objectContaining({ number: 'A-01' }),
                recordatorio: null, 
                actividades: expect.arrayContaining([
                    expect.objectContaining({ type: 'open' }) // Valida que 'abierto' se mapeó a 'open'
                ])
            }));
        });

        it('CP-02: Debería incluir un recordatorio si faltan menos de 24 hrs (1440 min)', async () => {
      
            const fechaCercana = new Date(Date.now() + (10 * 60 * 60 * 1000)); 
            
            db.query.mockResolvedValueOnce({ 
                rows: [{ number: 'B-02', building: 'Edificio 2', fecha_vencimiento: fechaCercana }] 
            });
            db.query.mockResolvedValueOnce({ rows: [] }); // Sin actividad reciente

            await getHomeData(req, res);

            
            expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
                recordatorio: expect.objectContaining({ titulo: "Renovación Próxima" })
            }));
        });

        it('CP-03: Debería retornar locker en null si el usuario no tiene casilleros asignados', async () => {
            db.query.mockResolvedValueOnce({ rows: [] }); // DB no encuentra casillero
            db.query.mockResolvedValueOnce({ rows: [] }); // DB no encuentra actividad

            await getHomeData(req, res);

            expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
                locker: null,
                recordatorio: null,
                actividades: []
            }));
        });

        it('CP-04: Debería retornar 500 si falla la base de datos', async () => {
            db.query.mockRejectedValueOnce(new Error('Falla de red en DB'));

            await getHomeData(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Error al cargar la pantalla de inicio." });
        });
    });
});