const {
    getUsuarios,
    crearUsuario,
    editarUsuario,
    cambiarEstado,
    buscarCompañeros
} = require('../controllers/usersController'); // Ajusta la ruta si es necesario
const db = require('../config/db');
const bcrypt = require('bcrypt');

// Falsificamos la conexión a la base de datos
jest.mock('../config/db', () => ({
    query: jest.fn()
}));

// Falsificamos bcrypt para acelerar las pruebas
jest.mock('bcrypt', () => ({
    genSalt: jest.fn(),
    hash: jest.fn()
}));

describe('Pruebas Unitarias - usersController', () => {
    let req, res;

    beforeEach(() => {
        jest.clearAllMocks();
        
        // Silenciamos los logs de error para mantener la terminal limpia
        jest.spyOn(console, 'error').mockImplementation(() => {});

        req = {
            user: { id: 1 },
            body: {},
            params: {},
            query: {}
        };
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    // ---------------------------------------------------------
    // 1. Pruebas para getUsuarios
    // ---------------------------------------------------------
    describe('getUsuarios', () => {
        test('CP-01: Debería obtener la lista de usuarios correctamente', async () => {
            const mockUsers = [{ id: 1, name: 'Admin', role: 'admin' }];
            db.query.mockResolvedValueOnce({ rows: mockUsers });

            await getUsuarios(req, res);

            expect(db.query).toHaveBeenCalledWith(expect.stringContaining('SELECT id, nombre_completo as name'));
            expect(res.json).toHaveBeenCalledWith(mockUsers);
        });

        test('CP-02: Debería manejar errores al obtener usuarios (500)', async () => {
            db.query.mockRejectedValueOnce(new Error("Error DB"));

            await getUsuarios(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Error al obtener usuarios" });
        });
    });

    // ---------------------------------------------------------
    // 2. Pruebas para crearUsuario
    // ---------------------------------------------------------
    describe('crearUsuario', () => {
        beforeEach(() => {
            req.body = { name: "Nuevo User", email: "nuevo@uteq.mx", matricula: "111", role: "alumno" };
        });

        test('CP-03: Debería crear un usuario exitosamente', async () => {
            bcrypt.genSalt.mockResolvedValueOnce('salt');
            bcrypt.hash.mockResolvedValueOnce('hashedDefaultPassword');
            
            const mockNewUser = { id: 2, name: "Nuevo User", status: "activo" };
            db.query.mockResolvedValueOnce({ rows: [mockNewUser] });

            await crearUsuario(req, res);

            expect(bcrypt.hash).toHaveBeenCalledWith('Uteq2026!', 'salt');
            expect(db.query).toHaveBeenCalledWith(
                expect.stringContaining('INSERT INTO users'),
                ["Nuevo User", "nuevo@uteq.mx", "111", "alumno", "hashedDefaultPassword"]
            );
            expect(res.status).toHaveBeenCalledWith(201);
            expect(res.json).toHaveBeenCalledWith(mockNewUser);
        });

        test('CP-04: Debería manejar errores de duplicidad al crear usuario (500)', async () => {
            db.query.mockRejectedValueOnce(new Error("Duplicidad de correo"));

            await crearUsuario(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ 
                mensaje: "Error al crear usuario (Revisa que la matrícula/correo no estén repetidos)" 
            });
        });
    });

    // ---------------------------------------------------------
    // 3. Pruebas para editarUsuario
    // ---------------------------------------------------------
    describe('editarUsuario', () => {
        beforeEach(() => {
            req.params = { id: 5 };
            req.body = { name: "Editado", email: "edit@uteq.mx", matricula: "222", role: "admin" };
        });

        test('CP-05: Debería editar un usuario exitosamente', async () => {
            const mockUpdatedUser = { id: 5, name: "Editado" };
            db.query.mockResolvedValueOnce({ rows: [mockUpdatedUser] });

            await editarUsuario(req, res);

            expect(db.query).toHaveBeenCalledWith(
                expect.stringContaining('UPDATE users SET nombre_completo'),
                ["Editado", "edit@uteq.mx", "222", "admin", 5]
            );
            expect(res.json).toHaveBeenCalledWith(mockUpdatedUser);
        });

        test('CP-06: Debería manejar errores al editar usuario (500)', async () => {
            db.query.mockRejectedValueOnce(new Error("Error SQL"));

            await editarUsuario(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Error al editar usuario" });
        });
    });

    // ---------------------------------------------------------
    // 4. Pruebas para cambiarEstado
    // ---------------------------------------------------------
    describe('cambiarEstado', () => {
        beforeEach(() => {
            req.params = { id: 10 };
        });

        test('CP-07: Debería desactivar un usuario si está activo', async () => {
            db.query
                .mockResolvedValueOnce({ rows: [{ status: 'activo' }] }) // Consulta inicial
                .mockResolvedValueOnce({}); // Update

            await cambiarEstado(req, res);

            expect(db.query).toHaveBeenCalledWith("UPDATE users SET status = $1 WHERE id = $2", ['inactivo', 10]);
            expect(res.json).toHaveBeenCalledWith({ id: 10, status: 'inactivo' });
        });

        test('CP-08: Debería activar un usuario si está inactivo', async () => {
            db.query
                .mockResolvedValueOnce({ rows: [{ status: 'inactivo' }] }) // Consulta inicial
                .mockResolvedValueOnce({}); // Update

            await cambiarEstado(req, res);

            expect(db.query).toHaveBeenCalledWith("UPDATE users SET status = $1 WHERE id = $2", ['activo', 10]);
            expect(res.json).toHaveBeenCalledWith({ id: 10, status: 'activo' });
        });

        test('CP-09: Debería manejar errores al cambiar estado (500)', async () => {
            db.query.mockRejectedValueOnce(new Error("Base de datos bloqueada"));

            await cambiarEstado(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Error al cambiar estado" });
        });
    });

    // ---------------------------------------------------------
    // 5. Pruebas para buscarCompañeros
    // ---------------------------------------------------------
    describe('buscarCompañeros', () => {
        beforeEach(() => {
            req.query = { q: "Juan" };
            req.user = { id: 1 };
        });

        test('CP-10: Debería filtrar y devolver compañeros de la misma carrera', async () => {
            // Simulamos obtener la carrera del usuario
            db.query.mockResolvedValueOnce({ rows: [{ carrera: 'Desarrollo de Software' }] });
            
            // Simulamos los resultados de la búsqueda (ILike)
            const mockCompañeros = [
                { id: 2, name: 'Juan Perez', matricula: '123' },
                { id: 3, name: 'San Juan', matricula: '456' }
            ];
            db.query.mockResolvedValueOnce({ rows: mockCompañeros });

            await buscarCompañeros(req, res);

            expect(db.query).toHaveBeenCalledWith(
                expect.stringContaining('SELECT id, nombre_completo as name, matricula'),
                ['Desarrollo de Software', 1, '%Juan%']
            );
            expect(res.json).toHaveBeenCalledWith(mockCompañeros);
        });

        test('CP-11: Debería manejar errores en la búsqueda (500)', async () => {
            db.query.mockRejectedValueOnce(new Error("Timeout de consulta"));

            await buscarCompañeros(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Error al buscar compañeros" });
        });
    });
});