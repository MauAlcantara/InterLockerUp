const { solicitarPinCorreo, abrirLockerRemoto } = require('../controllers/accessController'); 
const db = require('../config/db');
const crypto = require('crypto');
const { Resend } = require('resend');

// Burlar (Mock) la base de datos
jest.mock('../config/db', () => ({
    query: jest.fn()
}));

// Burlar (Mock) el servicio de Resend
jest.mock('resend', () => {
    return {
        Resend: jest.fn().mockImplementation(() => ({
            emails: {
                send: jest.fn().mockResolvedValue({ id: 'mock_email_id' })
            }
        }))
    };
});

describe('Controlador: accessController', () => {
    let req, res;

    beforeEach(() => {
        // Reiniciar los mocks antes de cada prueba
        jest.clearAllMocks();
        
        // Simular el objeto req (petición) de Express
        req = {
            user: { id: 1 },
            body: {}
        };

        // Simular el objeto res (respuesta) de Express
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    describe('Método: solicitarPinCorreo', () => {
        
        it('CP-01: Debería generar un PIN y enviar correo si el usuario tiene casillero', async () => {
            db.query.mockResolvedValueOnce({
                rows: [{ assignment_id: 10, email: 'test@correo.com', nombre_completo: 'Usuario Test' }]
            });
            db.query.mockResolvedValueOnce({}); 
            db.query.mockResolvedValueOnce({}); 

            await solicitarPinCorreo(req, res);

            expect(db.query).toHaveBeenCalledTimes(3);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "PIN de emergencia enviado a tu correo." });
        });

        it('CP-02: Debería retornar 404 si el usuario no tiene casillero asignado', async () => {
            db.query.mockResolvedValueOnce({ rows: [] });

            await solicitarPinCorreo(req, res);

            expect(res.status).toHaveBeenCalledWith(404);
            expect(res.json).toHaveBeenCalledWith({ mensaje: 'Sin casillero asignado.' });
        });

        it('CP-03: Debería retornar 500 si ocurre un error interno', async () => {
            db.query.mockRejectedValueOnce(new Error('Falla en DB'));

            await solicitarPinCorreo(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Error al solicitar el PIN o enviar el correo." });
        });
    });

    describe('Método: abrirLockerRemoto', () => {
        
        it('CP-04: Debería abrir el locker y registrar el acceso si el PIN es correcto y vigente', async () => {
            req.body.pin_ingresado = '123456';
            const hashSimulado = crypto.createHash("sha256").update('123456').digest("hex");
            const fechaFutura = new Date(Date.now() + 10000);

            db.query.mockResolvedValueOnce({
                rows: [{ assignment_id: 10, locker_id: 5, identificador: 'A-01' }]
            });
            db.query.mockResolvedValueOnce({
                rows: [{ pin_hash: hashSimulado, expires_at: fechaFutura }]
            });
            db.query.mockResolvedValueOnce({});
            db.query.mockResolvedValueOnce({});

            await abrirLockerRemoto(req, res);

            expect(res.json).toHaveBeenCalledWith({ mensaje: "¡Locker abierto exitosamente!" });
            expect(db.query).toHaveBeenCalledTimes(4);
        });

        it('CP-05: Debería retornar 404 si el usuario no tiene casillero', async () => {
            req.body.pin_ingresado = '123456';
            db.query.mockResolvedValueOnce({ rows: [] });

            await abrirLockerRemoto(req, res);

            expect(res.status).toHaveBeenCalledWith(404);
            expect(res.json).toHaveBeenCalledWith({ mensaje: 'Sin casillero asignado.' });
        });

        it('CP-06: Debería retornar 400 si no existe un PIN solicitado', async () => {
            req.body.pin_ingresado = '123456';
            db.query.mockResolvedValueOnce({
                rows: [{ assignment_id: 10, locker_id: 5, identificador: 'A-01' }]
            });
            db.query.mockResolvedValueOnce({ rows: [] }); 

            await abrirLockerRemoto(req, res);

            expect(res.status).toHaveBeenCalledWith(400);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "No has solicitado un PIN." });
        });

        it('CP-07: Debería retornar 400 si el PIN ha expirado', async () => {
            req.body.pin_ingresado = '123456';
            const fechaPasada = new Date(Date.now() - 10000); 
            
            db.query.mockResolvedValueOnce({
                rows: [{ assignment_id: 10, locker_id: 5, identificador: 'A-01' }]
            });
            db.query.mockResolvedValueOnce({
                rows: [{ pin_hash: 'algunhash', expires_at: fechaPasada }]
            });

            await abrirLockerRemoto(req, res);

            expect(res.status).toHaveBeenCalledWith(400);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "El PIN ha expirado. Solicita uno nuevo." });
        });

        it('CP-08: Debería retornar 400 si el PIN es incorrecto', async () => {
            req.body.pin_ingresado = '999999'; 
            const hashCorrecto = crypto.createHash("sha256").update('123456').digest("hex");
            const fechaFutura = new Date(Date.now() + 10000);
            
            db.query.mockResolvedValueOnce({
                rows: [{ assignment_id: 10, locker_id: 5, identificador: 'A-01' }]
            });
            db.query.mockResolvedValueOnce({
                rows: [{ pin_hash: hashCorrecto, expires_at: fechaFutura }]
            });

            await abrirLockerRemoto(req, res);

            expect(res.status).toHaveBeenCalledWith(400);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "PIN incorrecto." });
        });
    });
});