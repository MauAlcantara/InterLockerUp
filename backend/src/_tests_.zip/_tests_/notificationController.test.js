const {
    getNotifications,
    markAsRead,
    createNotification
} = require('../controllers/notificationController'); // Ajusta la ruta si es necesario
const db = require('../config/db');

// Falsificamos la conexión a la base de datos
jest.mock('../config/db', () => ({
    query: jest.fn()
}));

describe('Pruebas Unitarias - notificationController', () => {
    
    let req, res;

    // Antes de cada prueba, preparamos un entorno limpio
    beforeEach(() => {
        jest.clearAllMocks();

        // Silenciamos los console.error para una terminal limpia
        jest.spyOn(console, 'error').mockImplementation(() => {});

        req = {
            user: { id: 1 },
            body: {},
            params: {}
        };
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    // ---------------------------------------------------------
    // 1. Pruebas para getNotifications
    // ---------------------------------------------------------
    describe('getNotifications', () => {
        
        test('CP-11: Debería obtener las notificaciones del usuario (propias y globales)', async () => {
            const mockNotifications = [
                { id: 1, mensaje: 'Aviso 1', es_global: false },
                { id: 2, mensaje: 'Aviso global', es_global: true }
            ];
            
            // Simulamos respuesta exitosa de la BD
            db.query.mockResolvedValueOnce({ rows: mockNotifications });

            await getNotifications(req, res);

            expect(db.query).toHaveBeenCalled();
            // Verifica que devuelva el arreglo directamente
            expect(res.json).toHaveBeenCalledWith(mockNotifications); 
        });

        test('CP-12: Debería manejar errores de base de datos (500)', async () => {
            db.query.mockRejectedValueOnce(new Error("Error de conexión"));

            await getNotifications(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "error al obtener notificaciones" });
        });
    });

    // ---------------------------------------------------------
    // 2. Pruebas para markAsRead
    // ---------------------------------------------------------
    describe('markAsRead', () => {
        
        beforeEach(() => {
            req.params = { id: 5 }; // ID de la notificación a leer
        });

        test('CP-13: Debería marcar una notificación como leída exitosamente', async () => {
            db.query.mockResolvedValueOnce({ rowCount: 1 });

            await markAsRead(req, res);

            expect(db.query).toHaveBeenCalledWith(
                expect.stringContaining('update notifications'),
                [5]
            );
            expect(res.json).toHaveBeenCalledWith({ mensaje: "notificacion marcada como leida" });
        });

        test('CP-14: Debería manejar errores al marcar como leída (500)', async () => {
            db.query.mockRejectedValueOnce(new Error("Error SQL"));

            await markAsRead(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "error al actualizar notificacion" });
        });
    });

    // ---------------------------------------------------------
    // 3. Pruebas para createNotification
    // ---------------------------------------------------------
    describe('createNotification', () => {
        
        test('CP-15: Debería crear una notificación con todos los datos proporcionados', async () => {
            req.body = { 
                mensaje: "Mantenimiento programado", 
                tipo: "alerta", 
                user_id: 2, 
                es_global: true 
            };

            db.query.mockResolvedValueOnce({ rowCount: 1 });

            await createNotification(req, res);

            expect(db.query).toHaveBeenCalledWith(
                expect.stringContaining('insert into notifications'),
                ["Mantenimiento programado", "alerta", 2, true]
            );
            expect(res.json).toHaveBeenCalledWith({ mensaje: "notificacion creada" });
        });

        test('CP-16: Debería crear una notificación asignando los valores por defecto', async () => {
            // Mandamos solo el mensaje, el resto deberá tomar los valores fallback (||)
            req.body = { mensaje: "Bienvenido al sistema" };

            db.query.mockResolvedValueOnce({ rowCount: 1 });

            await createNotification(req, res);

            // Verificamos que se usen los valores por defecto: 'info', null y false
            expect(db.query).toHaveBeenCalledWith(
                expect.stringContaining('insert into notifications'),
                ["Bienvenido al sistema", "info", null, false]
            );
            expect(res.json).toHaveBeenCalledWith({ mensaje: "notificacion creada" });
        });

        test('CP-17: Debería manejar errores al intentar crear (500)', async () => {
            req.body = { mensaje: "Fallo" };
            db.query.mockRejectedValueOnce(new Error("Constraint violation"));

            await createNotification(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "error creando notificacion" });
        });
    });

});