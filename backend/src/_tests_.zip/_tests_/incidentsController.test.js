const { reportarIncidencia, getIncidenciasAdmin, actualizarIncidencia } = require('../controllers/incidentsController'); 
const db = require('../config/db');
const fs = require('fs');

// Burlar (Mock) las dependencias
jest.mock('../config/db', () => ({ query: jest.fn() }));
jest.mock('fs', () => ({ readFileSync: jest.fn() }));

describe('Controlador: incidentsController', () => {
    let req, res;

    beforeEach(() => {
        jest.clearAllMocks();
        req = { body: {}, params: {} };
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    describe('Método: reportarIncidencia', () => {
        beforeEach(() => {
            req.body = { userId: 1, lockerId: 5, categoria: 'Falla', descripcion: 'No abre' };
        });

        it('CP-01: Debería reportar una incidencia SIN evidencia correctamente', async () => {
            db.query.mockResolvedValueOnce({ rows: [{ id: 1, folio: 'INC-12345' }] });

            await reportarIncidencia(req, res);

            expect(db.query).toHaveBeenCalled();
          
            expect(res.status).toHaveBeenCalledWith(201);
            expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
                hashGenerado: null,
                mensaje: 'Incidencia reportada con éxito.'
            }));
        });

        it('CP-02: Debería calcular el Hash SHA-256 si incluye un archivo de evidencia', async () => {
            req.file = { path: '/uploads/foto.jpg' };
          
            fs.readFileSync.mockReturnValue(Buffer.from('datos_falsos')); 
            db.query.mockResolvedValueOnce({ rows: [{ id: 2 }] });

            await reportarIncidencia(req, res);

            expect(fs.readFileSync).toHaveBeenCalledWith('/uploads/foto.jpg');
            expect(res.status).toHaveBeenCalledWith(201);
            // El hash SHA-256 de 'datos_falsos' debe coincidir exactamente
            expect(res.json.mock.calls[0][0].hashGenerado).toBeDefined();
            expect(res.json.mock.calls[0][0].hashGenerado).not.toBeNull();
        });

        it('CP-03: Debería retornar 500 si falla la inserción', async () => {
            db.query.mockRejectedValueOnce(new Error('Falla DB'));

            await reportarIncidencia(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: 'Error interno al procesar el reporte.' });
        });
    });

    describe('Método: getIncidenciasAdmin', () => {
        it('CP-04: Debería obtener todas las incidencias', async () => {
            db.query.mockResolvedValueOnce({ rows: [{ id: 1, folio: 'INC-999' }] });

            await getIncidenciasAdmin(req, res);

            expect(res.json).toHaveBeenCalledWith([{ id: 1, folio: 'INC-999' }]);
        });

        it('CP-05: Debería retornar 500 si la consulta falla', async () => {
            db.query.mockRejectedValueOnce(new Error('Error DB'));

            await getIncidenciasAdmin(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
        });
    });

    describe('Método: actualizarIncidencia', () => {
        beforeEach(() => {
            req.params.id = 10;
            req.body = { estado: 'en_proceso', nuevo_comentario: 'Revisando chapa' };
        });

        it('CP-06: Debería actualizar la incidencia agregando el comentario y mapeando el estado', async () => {
            const historialAnterior = JSON.stringify([{ author: 'Admin', text: 'Recibido', date: '2026-06-14 10:00' }]);
            db.query.mockResolvedValueOnce({ rows: [{ observaciones_admin: historialAnterior }] });
            db.query.mockResolvedValueOnce({}); // Para el UPDATE

            await actualizarIncidencia(req, res);

          
            expect(db.query).toHaveBeenCalledTimes(2);
            
          
            const updateCallArgs = db.query.mock.calls[1];
            expect(updateCallArgs[0]).toContain('UPDATE incidents SET estado = $1');
            expect(updateCallArgs[1][0]).toBe('en proceso');
            expect(updateCallArgs[1][1]).toContain('Revisando chapa'); // Nuevo comentario en el JSON

            expect(res.json).toHaveBeenCalledWith({ mensaje: "Incidencia actualizada" });
        });

        it('CP-07: Debería retornar 500 si falla la actualización', async () => {
            db.query.mockRejectedValueOnce(new Error('Tabla bloqueada'));

            await actualizarIncidencia(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
        });
    });
});