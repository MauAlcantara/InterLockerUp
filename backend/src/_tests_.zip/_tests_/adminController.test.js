const { getNotificaciones, marcarIncidenciaLeida } = require('../controllers/adminController'); 
const db = require('../config/db');

// Burlar (Mock) la base de datos
jest.mock('../config/db', () => ({
    query: jest.fn()
}));

describe('Controlador: adminsController', () => {
    let req, res;

    beforeEach(() => {
        jest.clearAllMocks();
        
        // Simular req y res genéricos
        req = { params: {}, body: {} };
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    describe('Método: getNotificaciones', () => {
        
        it('CP-01: Debería obtener notificaciones calculando correctamente el tiempo relativo', async () => {
            const ahora = Date.now();
            
            const incidenciasSimuladas = [
                { id: 1, identificador: 'A-01', categoria: 'Falla física', fecha: new Date(ahora - 10000), estado: 'pendiente' },
                { id: 2, identificador: 'A-02', categoria: 'Mantenimiento', fecha: new Date(ahora - 300000), estado: 'en revisión' },
                { id: 3, identificador: 'B-01', categoria: 'Batería baja', fecha: new Date(ahora - 7200000), estado: 'resuelta' }
            ];

            db.query.mockResolvedValueOnce({ rows: incidenciasSimuladas });

            await getNotificaciones(req, res);

            expect(res.json).toHaveBeenCalled();
            const respuesta = res.json.mock.calls[0][0]; 
            expect(respuesta[0].tiempo).toBe('Hace un momento');
            expect(respuesta[1].tiempo).toBe('Hace 5 min');
            expect(respuesta[2].tiempo).toBe('Hace 2 horas');
        });

        it('CP-02: Debería mapear correctamente el estado de lectura (leida: true/false)', async () => {
            const incidenciasSimuladas = [
                { id: 1, identificador: 'A-01', categoria: 'Falla', fecha: new Date(), estado: 'pendiente' },
                { id: 2, identificador: 'A-02', categoria: 'Falla', fecha: new Date(), estado: 'resuelta' }
            ];

            db.query.mockResolvedValueOnce({ rows: incidenciasSimuladas });

            await getNotificaciones(req, res);

            const respuesta = res.json.mock.calls[0][0];
            
            
            expect(respuesta[0].leida).toBe(false);
            expect(respuesta[1].leida).toBe(true);
        });

        it('CP-03: Debería retornar 500 si la consulta falla', async () => {
            db.query.mockRejectedValueOnce(new Error('Falla de conexión'));

            await getNotificaciones(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Error interno del servidor" });
        });
    });

    describe('Método: marcarIncidenciaLeida', () => {
        
        it('CP-04: Debería actualizar el estado a "en revisión" exitosamente', async () => {
            req.params.id = 5; 
            db.query.mockResolvedValueOnce({}); 

            await marcarIncidenciaLeida(req, res);

            expect(db.query).toHaveBeenCalledWith(
                "UPDATE incidents SET estado = 'en revisión' WHERE id = $1 AND estado = 'pendiente'", 
                [5]
            );
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Incidencia en revisión" });
        });

        it('CP-05: Debería retornar 500 si ocurre un error al actualizar', async () => {
            req.params.id = 5;
            db.query.mockRejectedValueOnce(new Error('Tabla bloqueada'));

            await marcarIncidenciaLeida(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Error al actualizar la incidencia" });
        });
    });
});