const { getUserHistory } = require('../controllers/historyController'); 
const db = require('../config/db');
// Burlar (Mock) la base de datos
jest.mock('../config/db', () => ({
    query: jest.fn()
}));

describe('Controlador: historyController', () => {
    let req, res;

    beforeEach(() => {
        jest.clearAllMocks();
        
        req = {
            user: { id: 10 }
        };
        
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    describe('Método: getUserHistory', () => {
        
        it('CP-01: Debería obtener y consolidar el historial completo del usuario', async () => {
            // Mock 1: Resultados de las solicitudes (requests)
            db.query.mockResolvedValueOnce({
                rows: [{ id: 1, locker_id: 5, status: 'aprobada' }]
            });
            // Mock 2: Resultados de las asignaciones (assignments)
            db.query.mockResolvedValueOnce({
                rows: [{ id: 2, locker_id: 5, status: 'activa' }]
            });
            // Mock 3: Resultados de la bitácora (access logs)
            db.query.mockResolvedValueOnce({
                rows: [{ id: 3, accion: 'abrir', fecha_hora: '2026-06-14T10:00:00Z' }]
            });

            await getUserHistory(req, res);

            expect(db.query).toHaveBeenCalledTimes(3);
            
           
            expect(res.json).toHaveBeenCalledWith({
                requests: [{ id: 1, locker_id: 5, status: 'aprobada' }],
                assignments: [{ id: 2, locker_id: 5, status: 'activa' }],
                access_logs: [{ id: 3, accion: 'abrir', fecha_hora: '2026-06-14T10:00:00Z' }]
            });
        });

        it('CP-02: Debería retornar 500 si ocurre un error en la base de datos', async () => {
            db.query.mockRejectedValueOnce(new Error('Falla de conexión'));

            await getUserHistory(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ message: "error al obtener historial" });
        });
    });
});