const { login, getPublicKey, getCarreras } = require('../controllers/authController');
const db = require('../config/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Mocks de dependencias
jest.mock('../config/db', () => ({ query: jest.fn() }));
jest.mock('bcrypt', () => ({ compare: jest.fn() }));
jest.mock('jsonwebtoken', () => ({ sign: jest.fn() }));
jest.mock('resend', () => ({
    Resend: jest.fn().mockImplementation(() => ({
        emails: { send: jest.fn().mockResolvedValue({ id: 'mock_email' }) }
    }))
}));

describe('Controlador: authController', () => {
    let req, res;

    beforeEach(() => {
        jest.clearAllMocks();
        
        req = { body: {} };
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    describe('Método: getPublicKey', () => {
        it('CP-01: Debería retornar la llave pública RSA', () => {
            getPublicKey(req, res);
            expect(res.json).toHaveBeenCalled();
            expect(res.json.mock.calls[0][0]).toHaveProperty('publicKey');
        });
    });

    describe('Método: login', () => {
        beforeEach(() => {
            req.body = { email: 'valeria@uteq.edu.mx', password: 'password123', deviceId: 'dispositivo_conocido' };
        });

        it('CP-02: Debería hacer login exitoso si el dispositivo es reconocido', async () => {
            // Mock 1: Encuentra al usuario
            db.query.mockResolvedValueOnce({ rows: [{ id: 1, email: 'valeria@uteq.edu.mx', password_hash: 'hash' }] });
            // Mock 2: La contraseña coincide
            bcrypt.compare.mockResolvedValueOnce(true);
            // Mock 3: El dispositivo SÍ es reconocido
            db.query.mockResolvedValueOnce({ rows: [{ id: 1, device_fingerprint: 'dispositivo_conocido' }] });
            // Mock 4: Firma del JWT
            jwt.sign.mockReturnValue('fake_jwt_token');

            await login(req, res);

            expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
                mensaje: '¡Bienvenido!',
                token: 'fake_jwt_token'
            }));
        });

        it('CP-03: Debería retornar 401 si la contraseña es incorrecta', async () => {
            db.query.mockResolvedValueOnce({ rows: [{ id: 1 }] });
            bcrypt.compare.mockResolvedValueOnce(false); // Falla la contraseña

            await login(req, res);

            expect(res.status).toHaveBeenCalledWith(401);
            expect(res.json).toHaveBeenCalledWith({ mensaje: 'Contraseña incorrecta.' });
        });

        it('CP-04: Debería retornar 404 si el usuario no existe', async () => {
            db.query.mockResolvedValueOnce({ rows: [] }); // No encuentra usuario

            await login(req, res);

            expect(res.status).toHaveBeenCalledWith(404);
            expect(res.json).toHaveBeenCalledWith({ mensaje: 'Usuario no encontrado.' });
        });

        it('CP-05: Debería pedir OTP (Status 203) si el dispositivo es nuevo', async () => {
            req.body.deviceId = 'dispositivo_nuevo';

            db.query.mockResolvedValueOnce({ rows: [{ id: 1, email: 'test@uteq.edu.mx', password_hash: 'hash' }] });
            bcrypt.compare.mockResolvedValueOnce(true);
          
            db.query.mockResolvedValueOnce({ rows: [] }); 
           
            db.query.mockResolvedValueOnce({});

            await login(req, res);

            expect(res.status).toHaveBeenCalledWith(203);
            expect(res.json).toHaveBeenCalledWith({ mensaje: 'Verificación requerida', requiereOTP: true });
        });

        it('CP-06: Debería retornar 401 si el OTP ingresado es inválido', async () => {
            req.body.deviceId = 'dispositivo_nuevo';
            req.body.otpCode = '000000'; // Código incorrecto

            const fechaFutura = new Date(Date.now() + 10000); // Aún vigente
            db.query.mockResolvedValueOnce({ rows: [{ id: 1, temp_otp: '123456', otp_expires: fechaFutura }] });
            bcrypt.compare.mockResolvedValueOnce(true);
            db.query.mockResolvedValueOnce({ rows: [] }); 

            await login(req, res);

            expect(res.status).toHaveBeenCalledWith(401);
            expect(res.json).toHaveBeenCalledWith({ mensaje: 'Código de verificación inválido o expirado.' });
        });
    });

    describe('Método: getCarreras', () => {
        it('CP-07: Debería mapear y retornar el arreglo de carreras correctamente', async () => {
            db.query.mockResolvedValueOnce({ 
                rows: [{ career: 'Software' }, { career: 'Redes' }] 
            });

            await getCarreras(req, res);

            expect(res.json).toHaveBeenCalledWith(['Software', 'Redes']);
        });

        it('CP-08: Debería retornar 500 si falla la base de datos', async () => {
            db.query.mockRejectedValueOnce(new Error('Falla DB'));

            await getCarreras(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
        });
    });
});