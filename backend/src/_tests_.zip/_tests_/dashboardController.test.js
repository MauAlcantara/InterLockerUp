const { getDashboardStats } = require('../controllers/dashboardController'); 
const db = require('../config/db');

// Burlar (Mock) la base de datos
jest.mock('../config/db', () => ({
    query: jest.fn()
}));

describe('Controlador: dashboardController', () => {
    let req, res;

    beforeEach(() => {
        jest.clearAllMocks();
        
        req = {}; // Petición vacía
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    describe('Método: getDashboardStats', () => {
        
        it('CP-01: Debería obtener las estadísticas y calcular los porcentajes matemáticos correctamente', async () => {
           
            db.query.mockResolvedValueOnce({
                rows: [{ lockers_ocupados: '5', total_lockers: '10', lockers_disponibles: '5', accesos_hoy: '12' }]
            });
            //  Actividad reciente
            db.query.mockResolvedValueOnce({ rows: [{ accion: 'apertura', locker: 'A-01' }] });
            //  Alertas pendientes
            db.query.mockResolvedValueOnce({ rows: [{ folio: 'INC-01', categoria: 'Mantenimiento' }] });

            await getDashboardStats(req, res);

         
            expect(db.query).toHaveBeenCalledTimes(3);
            
          
            expect(res.json).toHaveBeenCalledWith({
                kpis: {
                    tasaOcupacion: 50, 
                    accesosHoy: 12,
                    tiempoPromedio: 4.2,
                    disponibilidad: 50 
                },
                actividadReciente: [{ accion: 'apertura', locker: 'A-01' }],
                alertas: [{ folio: 'INC-01', categoria: 'Mantenimiento' }]
            });
        });

        it('CP-02: Debería evitar división por cero si la base de datos no tiene casilleros aún', async () => {
            // Simula que el sistema es completamente nuevo y tiene 0 en todo
            db.query.mockResolvedValueOnce({
                rows: [{ lockers_ocupados: '0', total_lockers: '0', lockers_disponibles: '0', accesos_hoy: '0' }]
            });
            db.query.mockResolvedValueOnce({ rows: [] });
            db.query.mockResolvedValueOnce({ rows: [] });

            await getDashboardStats(req, res);

            // Si el código falla y divide por cero, arrojará NaN 
            expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
                kpis: expect.objectContaining({
                    tasaOcupacion: 0, 
                    disponibilidad: 0
                })
            }));
        });

        it('CP-03: Debería retornar 500 si alguna de las consultas a la base de datos falla', async () => {
            db.query.mockRejectedValueOnce(new Error('Caída de DB al buscar KPIs'));

            await getDashboardStats(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Error al cargar estadísticas del dashboard" });
        });
    });
});