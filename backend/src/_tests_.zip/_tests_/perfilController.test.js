const {
    getPerfil,
    editarDatos,
    desalojarCasillero,
    getLockerActivo
} = require('../controllers/perfilController'); // Ajusta la ruta si es necesario
const db = require('../config/db');

// Creamos un "cliente falso" para simular db.connect() de la transacción
const mockClient = {
    query: jest.fn(),
    release: jest.fn()
};

// Falsificamos la conexión a la base de datos completa
jest.mock('../config/db', () => ({
    query: jest.fn(),
    connect: jest.fn(() => mockClient)
}));

describe('Pruebas Unitarias - perfilController', () => {
    
    let req, res;

    beforeEach(() => {
        jest.clearAllMocks();
        
        // Silenciamos los logs de error para una consola limpia
        jest.spyOn(console, 'error').mockImplementation(() => {});

        req = {
            user: { id: 1 },
            body: {},
            params: {}
        };
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    // ---------------------------------------------------------
    // 1. Pruebas para getPerfil
    // ---------------------------------------------------------
    describe('getPerfil', () => {
        test('CP-01: Debería obtener los datos del perfil exitosamente', async () => {
            const mockPerfil = { id: 1, matricula: '123', nombre_completo: 'Juan' };
            db.query.mockResolvedValueOnce({ rows: [mockPerfil] });

            await getPerfil(req, res);

            expect(db.query).toHaveBeenCalled();
            expect(res.json).toHaveBeenCalledWith(mockPerfil);
        });

        test('CP-02: Debería manejar errores de BD al obtener perfil (500)', async () => {
            db.query.mockRejectedValueOnce(new Error("Error SQL"));

            await getPerfil(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ error: "Error al obtener perfil" });
        });
    });

    // ---------------------------------------------------------
    // 2. Pruebas para editarDatos
    // ---------------------------------------------------------
    describe('editarDatos', () => {
        test('CP-03: Debería actualizar los datos correctamente', async () => {
            req.body = { nombre_completo: "Juan Perez", carrera: "TI" };
            db.query.mockResolvedValueOnce({ rowCount: 1 });

            await editarDatos(req, res);

            expect(db.query).toHaveBeenCalledWith(
                expect.stringContaining('UPDATE users'),
                ["Juan Perez", "TI", null, null, 1] // Usa null por defecto si faltan datos
            );
            expect(res.json).toHaveBeenCalledWith({ message: "Datos actualizados correctamente" });
        });

        test('CP-04: Debería manejar errores al actualizar (500)', async () => {
            db.query.mockRejectedValueOnce(new Error("Fallo de BD"));

            await editarDatos(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ error: "Error al actualizar el perfil" });
        });
    });

    // ---------------------------------------------------------
    // 3. Pruebas para desalojarCasillero
    // ---------------------------------------------------------
    describe('desalojarCasillero', () => {
        
        test('CP-05: Debería fallar si no hay usuario en el token (401)', async () => {
            req.user = null; // Simulamos que falta el usuario
            await desalojarCasillero(req, res);
            expect(res.status).toHaveBeenCalledWith(401);
            expect(res.json).toHaveBeenCalledWith({ error: "No se pudo identificar al usuario del token" });
        });

        test('CP-06: Debería retornar 404 si no tiene asignación activa', async () => {
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({ rows: [] }); // 0 asignaciones activas

            await desalojarCasillero(req, res);

            expect(mockClient.query).toHaveBeenCalledWith('ROLLBACK');
            expect(res.status).toHaveBeenCalledWith(404);
        });

        test('CP-07: Desalojo exitoso: No compartido, sin solicitud previa', async () => {
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({ rows: [{ assignment_id: 1, es_compartido: false, locker_id: 10 }] }) // findQuery
                .mockResolvedValueOnce({ rows: [] }) // Sin solicitud (request = undefined)
                .mockResolvedValueOnce({}) // UPDATE assignments
                .mockResolvedValueOnce({}) // UPDATE lockers
                .mockResolvedValueOnce({}) // DELETE qr_tokens
                .mockResolvedValueOnce({}) // DELETE pin_tokens
                .mockResolvedValueOnce({}); // COMMIT

            await desalojarCasillero(req, res);

            expect(res.json).toHaveBeenCalledWith({ message: "Casillero desalojado correctamente" });
        });

        test('CP-08: Desalojo exitoso: Compartido, quedan compañeros, solicitud no es tuya', async () => {
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({ rows: [{ assignment_id: 1, es_compartido: true, locker_id: 10 }] }) 
                .mockResolvedValueOnce({ rows: [{ id: 5, shared: true, user_id: 2, companions: [1] }] }) // Request es del user 2
                .mockResolvedValueOnce({}) // DELETE assignment_users
                .mockResolvedValueOnce({ rows: [{ '?column?': 1 }] }) // checkOthers (queda alguien más)
                .mockResolvedValueOnce({}) // array_remove(companions)
                .mockResolvedValueOnce({}); // COMMIT

            await desalojarCasillero(req, res);
            expect(mockClient.query).toHaveBeenCalledWith(expect.stringContaining('array_remove'), [1, 5]);
            expect(res.json).toHaveBeenCalledWith({ message: "Casillero desalojado correctamente" });
        });

        test('CP-09: Desalojo exitoso: Compartido, dueño se va y le deja el casillero al compañero', async () => {
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({ rows: [{ assignment_id: 1, es_compartido: true, locker_id: 10 }] }) 
                .mockResolvedValueOnce({ rows: [{ id: 5, shared: true, user_id: 1, companions: [2] }] }) // Request es del user 1 (dueño) con compa 2
                .mockResolvedValueOnce({}) // DELETE assignment_users
                .mockResolvedValueOnce({ rows: [] }) // checkOthers (0 rows, requiere limpiar tokens)
                .mockResolvedValueOnce({}) // UPDATE assignments
                .mockResolvedValueOnce({}) // UPDATE lockers
                .mockResolvedValueOnce({}) // DELETE qr
                .mockResolvedValueOnce({}) // DELETE pin
                .mockResolvedValueOnce({}) // UPDATE locker_requests (promueve al user 2)
                .mockResolvedValueOnce({}); // COMMIT

            await desalojarCasillero(req, res);
            expect(mockClient.query).toHaveBeenCalledWith(expect.stringContaining('shared = false'), [2, 5]);
        });

        test('CP-10: Desalojo exitoso: Compartido, dueño se va pero no quedan compañeros (Borra solicitud)', async () => {
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({ rows: [{ assignment_id: 1, es_compartido: true, locker_id: 10 }] }) 
                .mockResolvedValueOnce({ rows: [{ id: 5, shared: true, user_id: 1, companions: [] }] }) // Request dueño sin compas
                .mockResolvedValueOnce({}) // DELETE assignment_users
                .mockResolvedValueOnce({ rows: [] }) // checkOthers (0 rows)
                .mockResolvedValueOnce({}) // UPDATE assignments
                .mockResolvedValueOnce({}) // UPDATE lockers
                .mockResolvedValueOnce({}) // DELETE qr
                .mockResolvedValueOnce({}) // DELETE pin
                .mockResolvedValueOnce({}) // DELETE locker_requests
                .mockResolvedValueOnce({}); // COMMIT

            await desalojarCasillero(req, res);
            expect(mockClient.query).toHaveBeenCalledWith(expect.stringContaining('DELETE FROM locker_requests'), [5]);
        });

        test('CP-11: Desalojo exitoso: No compartido, con solicitud individual', async () => {
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({ rows: [{ assignment_id: 1, es_compartido: false, locker_id: 10 }] }) 
                .mockResolvedValueOnce({ rows: [{ id: 5, shared: false, user_id: 1 }] }) // Request individual
                .mockResolvedValueOnce({}) // UPDATE assignments
                .mockResolvedValueOnce({}) // UPDATE lockers
                .mockResolvedValueOnce({}) // DELETE qr
                .mockResolvedValueOnce({}) // DELETE pin
                .mockResolvedValueOnce({}) // DELETE locker_requests (Individual)
                .mockResolvedValueOnce({}); // COMMIT

            await desalojarCasillero(req, res);
            expect(res.json).toHaveBeenCalledWith({ message: "Casillero desalojado correctamente" });
        });

        test('CP-12: Debería manejar un error interno y ejecutar ROLLBACK (500)', async () => {
            mockClient.query.mockRejectedValueOnce(new Error("Error interno simulado"));

            await desalojarCasillero(req, res);

            expect(mockClient.query).toHaveBeenCalledWith('ROLLBACK');
            expect(mockClient.release).toHaveBeenCalled();
            expect(res.status).toHaveBeenCalledWith(500);
        });
    });

    // ---------------------------------------------------------
    // 4. Pruebas para getLockerActivo
    // ---------------------------------------------------------
    describe('getLockerActivo', () => {
        
        test('CP-13: Debería devolver null si el usuario no tiene casillero activo', async () => {
            db.query.mockResolvedValueOnce({ rows: [] });

            await getLockerActivo(req, res);

            expect(res.json).toHaveBeenCalledWith(null);
        });

        test('CP-14: Debería devolver el casillero con el tiempo restante calculado', async () => {
            // Simulamos una fecha de vencimiento de 1 hora a partir de ahora
            const futureDate = new Date(Date.now() + 60 * 60 * 1000).toISOString();
            const mockLocker = { id: 1, numero: 'A1', edificio: 'B1', fecha_vencimiento: futureDate };
            
            db.query.mockResolvedValueOnce({ rows: [mockLocker] });

            await getLockerActivo(req, res);

            // Verificamos que contenga la propiedad timeLeft calculada
            expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
                id: 1,
                numero: 'A1',
                timeLeft: expect.any(Number) // Acepta cualquier número calculado
            }));
        });

        test('CP-15: Debería manejar errores al consultar el casillero activo (500)', async () => {
            db.query.mockRejectedValueOnce(new Error("Fallo de BD"));

            await getLockerActivo(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ error: "Error al obtener casillero" });
        });
    });

});