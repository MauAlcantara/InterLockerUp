const { getAuditorias } = require('../controllers/auditsController'); 
const db = require('../config/db');

// Burlar (Mock) la base de datos
jest.mock('../config/db', () => ({
    query: jest.fn()
}));

describe('Controlador: auditsController', () => {
    let req, res;

    beforeEach(() => {
        jest.clearAllMocks();
        
        req = {}; 
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    describe('Método: getAuditorias', () => {
        
        it('CP-01: Debería obtener los 3 historiales simultáneamente y combinarlos en un solo JSON', async () => {
            // Mock para la Promesa 1: accessReq
            db.query.mockResolvedValueOnce({ rows: [{ id: 1, action: 'app movil', user: 'Mauricio' }] });
            // Mock para la Promesa 2: assignmentsReq
            db.query.mockResolvedValueOnce({ rows: [{ id: 2, action: 'asignacion', user: 'Elian' }] });
            // Mock para la Promesa 3: incidentsReq
            db.query.mockResolvedValueOnce({ rows: [{ id: 3, status: 'en_proceso', reportedBy: 'Celeste' }] });

            await getAuditorias(req, res);

          
            expect(db.query).toHaveBeenCalledTimes(3);
            
            
            expect(res.json).toHaveBeenCalledWith({
                accessLogs: [{ id: 1, action: 'app movil', user: 'Mauricio' }],
                assignmentLogs: [{ id: 2, action: 'asignacion', user: 'Elian' }],
                incidentLogs: [{ id: 3, status: 'en_proceso', reportedBy: 'Celeste' }]
            });
        });

        it('CP-02: Debería retornar 500 si alguna de las consultas a la base de datos falla', async () => {
        
            db.query.mockRejectedValueOnce(new Error('Error de conexión en DB'));

            await getAuditorias(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Error al cargar el historial de auditorías" });
        });
    });
});