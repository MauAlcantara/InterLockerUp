const {
    getAvailableLockers,
    assignLocker,
    getAllLockersAdmin,
    assignLockerAdmin,
    releaseLockerAdmin,
    changeLockerStatusAdmin,
    approveLockerRequestAdmin,
    getPendingRequestsAdmin,
    rejectLockerRequestAdmin
} = require('../controllers/lockerController'); // Ajusta la ruta si es necesario
const db = require('../config/db');

// Cliente falso para simular transacciones
const mockClient = {
    query: jest.fn(),
    release: jest.fn()
};

jest.mock('../config/db', () => ({
    query: jest.fn(),
    connect: jest.fn(() => mockClient)
}));

describe('Pruebas Unitarias - lockerController', () => {
    let req, res;

    beforeEach(() => {
        jest.clearAllMocks();
        jest.spyOn(console, 'error').mockImplementation(() => {});

        req = {
            user: { id: 1 },
            body: {},
            params: {}
        };
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    // --- MÉTODOS GENERALES ---
    describe('getAvailableLockers', () => {
        test('Debería obtener casilleros disponibles', async () => {
            db.query.mockResolvedValueOnce({ rows: [{ id: 1 }] });
            await getAvailableLockers(req, res);
            expect(res.json).toHaveBeenCalledWith([{ id: 1 }]);
        });
        test('Debería manejar errores (500)', async () => {
            db.query.mockRejectedValueOnce(new Error('BD Error'));
            await getAvailableLockers(req, res);
            expect(res.status).toHaveBeenCalledWith(500);
        });
    });

    describe('assignLocker', () => {
        test('Debería asignar un casillero si está disponible', async () => {
            req.body = { locker_id: 1, es_compartido: true, partner_id: 2, fecha_vencimiento: '2026-12-31' };
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({ rows: [{ estado: 'disponible' }] }) // Check
                .mockResolvedValueOnce({ rows: [{ id: 10 }] }) // Insert Assignment
                .mockResolvedValueOnce({}) // Insert User 1
                .mockResolvedValueOnce({}) // Insert Partner
                .mockResolvedValueOnce({}) // Update Locker
                .mockResolvedValueOnce({}); // COMMIT

            await assignLocker(req, res);
            expect(res.status).toHaveBeenCalledWith(201);
        });

        test('Debería hacer ROLLBACK si no está disponible', async () => {
            req.body = { locker_id: 1 };
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({ rows: [{ estado: 'ocupado' }] }); // Check falla

            await assignLocker(req, res);
            expect(mockClient.query).toHaveBeenCalledWith('ROLLBACK');
            expect(res.status).toHaveBeenCalledWith(400);
        });
    });

    describe('getAllLockersAdmin', () => {
        test('Debería listar todos los lockers', async () => {
            db.query.mockResolvedValueOnce({ rows: [{ id: 1 }] });
            await getAllLockersAdmin(req, res);
            expect(res.json).toHaveBeenCalled();
        });
        test('Debería manejar errores (500)', async () => {
            db.query.mockRejectedValueOnce(new Error('BD Error'));
            await getAllLockersAdmin(req, res);
            expect(res.status).toHaveBeenCalledWith(500);
        });
    });

    describe('assignLockerAdmin', () => {
        test('Debería asignar manualmente como admin', async () => {
            req.body = { locker_id: 1, matricula_usuario: '123' };
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({ rows: [{ id: 5 }] }) // User found
                .mockResolvedValueOnce({ rows: [{ estado: 'disponible' }] }) // Locker check
                .mockResolvedValueOnce({ rows: [{ id: 10 }] }) // Insert Assignment
                .mockResolvedValueOnce({}) // Insert User
                .mockResolvedValueOnce({}) // Update Locker
                .mockResolvedValueOnce({}); // COMMIT

            await assignLockerAdmin(req, res);
            expect(res.status).toHaveBeenCalledWith(201);
        });

        test('Debería fallar si usuario no existe', async () => {
            req.body = { locker_id: 1, matricula_usuario: '123' };
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({ rows: [] }); // User NO found

            await assignLockerAdmin(req, res);
            expect(res.status).toHaveBeenCalledWith(400);
        });

        test('Debería fallar si casillero está ocupado', async () => {
            req.body = { locker_id: 1, matricula_usuario: '123' };
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({ rows: [{ id: 5 }] }) // User found
                .mockResolvedValueOnce({ rows: [{ estado: 'ocupado' }] }); // Locker check falla

            await assignLockerAdmin(req, res);
            expect(res.status).toHaveBeenCalledWith(400);
        });
    });

    describe('releaseLockerAdmin', () => {
        test('Debería liberar el casillero', async () => {
            req.params = { id: 1 };
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({}) // Update Assignment
                .mockResolvedValueOnce({}) // Update Locker
                .mockResolvedValueOnce({}); // COMMIT

            await releaseLockerAdmin(req, res);
            expect(res.json).toHaveBeenCalled();
        });
        test('Debería manejar errores de liberación', async () => {
            req.params = { id: 1 };
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockRejectedValueOnce(new Error('Crash')); 

            await releaseLockerAdmin(req, res);
            expect(res.status).toHaveBeenCalledWith(500);
        });
    });

    // --- MÉTODOS SOLICITADOS ---
    describe('changeLockerStatusAdmin', () => {
        beforeEach(() => { req.params = { id: 1 }; req.body = { nuevo_estado: 'mantenimiento' }; });

        test('CP-01: Debería cambiar el estado exitosamente (200)', async () => {
            db.query.mockResolvedValueOnce({ rowCount: 1 });
            await changeLockerStatusAdmin(req, res);
            expect(db.query).toHaveBeenCalledWith("UPDATE lockers SET estado = $1 WHERE id = $2", ['mantenimiento', 1]);
            expect(res.json).toHaveBeenCalledWith({ mensaje: `Estado actualizado a mantenimiento` });
        });

        test('CP-02: Debería manejar errores de base de datos (500)', async () => {
            db.query.mockRejectedValueOnce(new Error('Error de BD'));
            await changeLockerStatusAdmin(req, res);
            expect(res.status).toHaveBeenCalledWith(500);
        });
    });

    describe('approveLockerRequestAdmin', () => {
        beforeEach(() => { req.params = { requestId: 5 }; });

        test('CP-03: Debería aprobar y procesar la solicitud (compartida)', async () => {
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({ rows: [{ locker_id: 10, shared: true, user_id: 1, companions: [2] }] }) // Request encontrada
                .mockResolvedValueOnce({ rows: [{ id: 50 }] }) // Insert Assignment
                .mockResolvedValueOnce({}) // Vincula Dueño
                .mockResolvedValueOnce({}) // Vincula Compa (loop)
                .mockResolvedValueOnce({}) // Update request
                .mockResolvedValueOnce({}) // Update locker
                .mockResolvedValueOnce({}) // Reject otras
                .mockResolvedValueOnce({}) // Notificación
                .mockResolvedValueOnce({}); // COMMIT

            await approveLockerRequestAdmin(req, res);
            expect(mockClient.query).toHaveBeenCalledWith('COMMIT');
            expect(res.json).toHaveBeenCalledWith({ mensaje: '¡Solicitud aprobada y casillero asignado oficialmente!' });
        });

        test('CP-04: Debería hacer ROLLBACK si la solicitud no existe', async () => {
            mockClient.query
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({ rows: [] }); // 0 rows (no existe o ya no es pending)

            await approveLockerRequestAdmin(req, res);
            expect(mockClient.query).toHaveBeenCalledWith('ROLLBACK');
            expect(res.status).toHaveBeenCalledWith(400);
            expect(res.json).toHaveBeenCalledWith({ mensaje: 'La solicitud no existe o ya fue procesada.' });
        });
    });

    describe('getPendingRequestsAdmin', () => {
        test('CP-05: Debería listar todas las solicitudes pendientes', async () => {
            const mockRequests = [{ id: 1, status: 'pending' }];
            db.query.mockResolvedValueOnce({ rows: mockRequests });

            await getPendingRequestsAdmin(req, res);
            expect(res.json).toHaveBeenCalledWith(mockRequests);
        });

        test('CP-06: Debería manejar errores de lectura (500)', async () => {
            db.query.mockRejectedValueOnce(new Error('Saturación BD'));

            await getPendingRequestsAdmin(req, res);
            expect(res.status).toHaveBeenCalledWith(500);
        });
    });

    describe('rejectLockerRequestAdmin', () => {
        beforeEach(() => { req.params = { requestId: 9 }; });

        test('CP-07: Debería rechazar, liberar casillero y notificar', async () => {
            db.query
                .mockResolvedValueOnce({ rows: [{ locker_id: 10, user_id: 1 }] }) // Encuentra solicitud
                .mockResolvedValueOnce({}) // Update request to rejected
                .mockResolvedValueOnce({}) // Update locker a disponible
                .mockResolvedValueOnce({}); // Notificación

            await rejectLockerRequestAdmin(req, res);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Solicitud rechazada" });
        });

        test('CP-08: Debería retornar 404 si la solicitud a rechazar no existe', async () => {
            db.query.mockResolvedValueOnce({ rows: [] }); // 0 rows

            await rejectLockerRequestAdmin(req, res);
            expect(res.status).toHaveBeenCalledWith(404);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Solicitud no encontrada" });
        });

        test('CP-09: Debería manejar fallo interno de servidor (500)', async () => {
            db.query.mockRejectedValueOnce(new Error('Crash DB'));

            await rejectLockerRequestAdmin(req, res);
            expect(res.status).toHaveBeenCalledWith(500);
        });
    });
});