const registerUserController = require('../controllers/registerUserController'); // Ajusta la ruta si es necesario
const db = require('../config/db');
const bcrypt = require('bcrypt');

// Falsificamos la conexión a la base de datos
jest.mock('../config/db', () => ({
    query: jest.fn()
}));

// Falsificamos bcrypt para no gastar recursos reales hasheando durante la prueba
jest.mock('bcrypt', () => ({
    genSalt: jest.fn(),
    hash: jest.fn()
}));

describe('Pruebas Unitarias - registerUserController', () => {
    let req, res;

    beforeEach(() => {
        jest.clearAllMocks();

        // Silenciamos los console.error para una terminal limpia
        jest.spyOn(console, 'error').mockImplementation(() => {});

        // Preparamos un cuerpo de petición válido por defecto
        req = {
            body: {
                matricula: '2023001',
                nombre_completo: 'Test User',
                email: 'test@uteq.mx',
                password: 'Password123!',
                carrera: 'Desarrollo de Software'
            }
        };
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    test('CP-01: Debería rechazar si faltan campos obligatorios (400)', async () => {
        // Quitamos la contraseña para simular un envío incompleto
        req.body.password = undefined;

        await registerUserController(req, res);

        expect(res.status).toHaveBeenCalledWith(400);
        expect(res.json).toHaveBeenCalledWith({
            mensaje: "Todos los campos obligatorios deben completarse"
        });
        // Verificamos que no intentó hacer ninguna consulta a BD
        expect(db.query).not.toHaveBeenCalled();
    });

    test('CP-02: Debería rechazar si la matrícula o correo ya existen (400)', async () => {
        // Simulamos que el SELECT devuelve 1 fila (ya existe)
        db.query.mockResolvedValueOnce({ rows: [{ id: 1 }] });

        await registerUserController(req, res);

        expect(res.status).toHaveBeenCalledWith(400);
        expect(res.json).toHaveBeenCalledWith({
            mensaje: "La matrícula o el correo ya están registrados"
        });
    });

    test('CP-03: Debería registrar usuario exitosamente (201)', async () => {
        // Simulamos que el usuario NO existe (0 filas devueltas en el SELECT)
        db.query.mockResolvedValueOnce({ rows: [] });
        
        // Simulamos la generación del Hash seguro
        bcrypt.genSalt.mockResolvedValueOnce('mockedSalt');
        bcrypt.hash.mockResolvedValueOnce('hashedPassword123');

        // Simulamos el INSERT devolviendo el nuevo usuario
        const mockNewUser = { id: 2, matricula: '2023001', nombre_completo: 'Test User', email: 'test@uteq.mx' };
        db.query.mockResolvedValueOnce({ rows: [mockNewUser] });

        await registerUserController(req, res);

        // Verificamos que se haya intentado hacer el Hash de la contraseña
        expect(bcrypt.hash).toHaveBeenCalledWith('Password123!', 'mockedSalt');

        // Verificamos el rol 'alumno' por defecto en la consulta
        expect(db.query).toHaveBeenCalledWith(
            expect.stringContaining('insert into users'),
            ['2023001', 'Test User', 'test@uteq.mx', 'hashedPassword123', 'alumno', 'Desarrollo de Software']
        );

        expect(res.status).toHaveBeenCalledWith(201);
        expect(res.json).toHaveBeenCalledWith({
            mensaje: "Usuario registrado correctamente",
            usuario: mockNewUser
        });
    });

    test('CP-04: Debería manejar un fallo interno del servidor (500)', async () => {
        // Simulamos una caída de la base de datos durante el proceso
        db.query.mockRejectedValueOnce(new Error("Conexión perdida con PostgreSQL"));

        await registerUserController(req, res);

        expect(res.status).toHaveBeenCalledWith(500);
        expect(res.json).toHaveBeenCalledWith({
            mensaje: "Error al registrar usuario"
        });
    });
});