const { 
    createLockerRequest, 
    getUserLockerRequests, 
    getAvailableLockers, 
    cancelLockerRequest 
} = require('../controllers/lockerRequestController');
const db = require('../config/db');

// Falsificamos la conexión a la base de datos
jest.mock('../config/db', () => ({
    query: jest.fn()
}));

describe('Pruebas Unitarias - lockerRequestController', () => {
    
    let req, res;

    // Antes de cada prueba, preparamos un entorno limpio
    beforeEach(() => {
        jest.clearAllMocks();

        // Silenciamos los console.log y console.error durante las pruebas
        jest.spyOn(console, 'log').mockImplementation(() => {});
        jest.spyOn(console, 'error').mockImplementation(() => {});

        req = {
            user: { id: 1 },
            body: {},
            params: {}
        };
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    // ---------------------------------------------------------
    // 1. Pruebas para createLockerRequest
    // ---------------------------------------------------------
    describe('createLockerRequest', () => {
        
        beforeEach(() => {
            req.body = { lockerId: 10, isShared: false, partners: [] };
        });

        test('CP-01: Debería fallar si el usuario ya tiene un casillero asignado (400)', async () => {
            db.query.mockResolvedValueOnce({ rowCount: 1 });

            await createLockerRequest(req, res);

            expect(res.status).toHaveBeenCalledWith(400);
            expect(res.json).toHaveBeenCalledWith({ message: "Ya posees un casillero asignado actualmente." });
        });

        test('CP-02: Debería fallar si ya tiene una solicitud pendiente (400)', async () => {
            db.query.mockResolvedValueOnce({ rowCount: 0 });
            db.query.mockResolvedValueOnce({ rowCount: 1 });

            await createLockerRequest(req, res);

            expect(res.status).toHaveBeenCalledWith(400);
            expect(res.json).toHaveBeenCalledWith({ message: "Ya tienes una solicitud de casillero en proceso." });
        });

        test('CP-03: Debería crear la solicitud exitosamente (201)', async () => {
            db.query
                .mockResolvedValueOnce({ rowCount: 0 }) 
                .mockResolvedValueOnce({ rowCount: 0 }) 
                .mockResolvedValueOnce({}) 
                .mockResolvedValueOnce({}) 
                .mockResolvedValueOnce({ rows: [{ id: 99 }] }) 
                .mockResolvedValueOnce({}) 
                .mockResolvedValueOnce({}); 

            await createLockerRequest(req, res);

            expect(res.status).toHaveBeenCalledWith(201);
            expect(res.json).toHaveBeenCalledWith({ 
                mensaje: "Solicitud enviada correctamente", 
                requestId: 99 
            });
        });

        test('CP-04: Debería manejar errores y hacer ROLLBACK (500)', async () => {
            db.query.mockRejectedValueOnce(new Error("Error de BD"));

            await createLockerRequest(req, res);

            expect(db.query).toHaveBeenCalledWith('ROLLBACK');
            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({
                mensaje: "No se pudo procesar la solicitud",
                error: "Error de BD"
            });
        });
    });

    // ---------------------------------------------------------
    // 2. Pruebas para getUserLockerRequests
    // ---------------------------------------------------------
    describe('getUserLockerRequests', () => {
        
        test('CP-05: Debería devolver las solicitudes del usuario', async () => {
            const mockSolicitudes = [{ id: 1, locker_identificador: 'A1' }];
            db.query.mockResolvedValueOnce({ rows: mockSolicitudes });

            await getUserLockerRequests(req, res);

            expect(res.json).toHaveBeenCalledWith({ solicitudes: mockSolicitudes });
        });

        test('CP-06: Debería manejar errores de servidor (500)', async () => {
            db.query.mockRejectedValueOnce(new Error("Fallo en la BD"));

            await getUserLockerRequests(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: 'Error al obtener las solicitudes de locker.' });
        });
    });

    // ---------------------------------------------------------
    // 3. Pruebas para getAvailableLockers
    // ---------------------------------------------------------
    describe('getAvailableLockers', () => {
        
        test('CP-07: Debería retornar 404 si el usuario no existe', async () => {
            db.query.mockResolvedValueOnce({ rows: [] }); 

            await getAvailableLockers(req, res);

            expect(res.status).toHaveBeenCalledWith(404);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Usuario no encontrado" });
        });

        test('CP-08: Debería devolver los lockers disponibles según la carrera', async () => {
            db.query.mockResolvedValueOnce({ rows: [{ carrera: 'Desarrollo de Software' }] });
            const mockLockers = [{ id: 10, identificador: 'B2', estado: 'disponible' }];
            db.query.mockResolvedValueOnce({ rows: mockLockers });

            await getAvailableLockers(req, res);

            expect(res.json).toHaveBeenCalledWith({ lockers: mockLockers });
        });
    });

    // ---------------------------------------------------------
    // 4. Pruebas para cancelLockerRequest
    // ---------------------------------------------------------
    describe('cancelLockerRequest', () => {
        
        beforeEach(() => {
            req.params = { requestId: 5 };
        });

        test('CP-09: Debería fallar si la solicitud no existe o no está pendiente (400)', async () => {
            db.query
                .mockResolvedValueOnce({}) 
                .mockResolvedValueOnce({ rowCount: 0 }); 

            await cancelLockerRequest(req, res);

            expect(db.query).toHaveBeenCalledWith('ROLLBACK');
            expect(res.status).toHaveBeenCalledWith(400);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "No se encontró la solicitud o ya no se puede cancelar." });
        });

        test('CP-10: Debería cancelar la solicitud y liberar el locker (200)', async () => {
            db.query
                .mockResolvedValueOnce({}) 
                .mockResolvedValueOnce({ rowCount: 1, rows: [{ locker_id: 10 }] }) 
                .mockResolvedValueOnce({}) 
                .mockResolvedValueOnce({}) 
                .mockResolvedValueOnce({}); 

            await cancelLockerRequest(req, res);

            expect(res.json).toHaveBeenCalledWith({ mensaje: "Solicitud cancelada y locker liberado." });
            expect(db.query).toHaveBeenCalledWith('COMMIT');
        });
    });

});