const { generateQRToken, validarQRToken } = require('../controllers/qrController'); // Ajusta la ruta si es necesario
const db = require('../config/db');

// Falsificamos la conexión a la base de datos
jest.mock('../config/db', () => ({
    query: jest.fn()
}));

describe('Pruebas Unitarias - qrController', () => {
    let req, res;

    beforeEach(() => {
        jest.clearAllMocks();

        // Silenciamos los console.error para una terminal limpia
        jest.spyOn(console, 'error').mockImplementation(() => {});

        req = {
            user: { id: 1 },
            body: {}
        };
        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };
    });

    // ---------------------------------------------------------
    // 1. Pruebas para generateQRToken
    // ---------------------------------------------------------
    describe('generateQRToken', () => {

        test('CP-01: Debería devolver 404 si el usuario no tiene casillero activo', async () => {
            // Simulamos que la consulta no devuelve ningún casillero asignado
            db.query.mockResolvedValueOnce({ rows: [] });

            await generateQRToken(req, res);

            expect(res.status).toHaveBeenCalledWith(404);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "No tienes un casillero asignado o tu acceso ha expirado." });
        });

        test('CP-02: Debería generar el QR exitosamente (transacción COMMIT)', async () => {
            const mockAssignment = { assignment_id: 10, locker_id: 5, locker_numero: 'A-05' };
            
            db.query
                .mockResolvedValueOnce({ rows: [mockAssignment] }) // Select asignación
                .mockResolvedValueOnce({}) // BEGIN
                .mockResolvedValueOnce({}) // DELETE tokens anteriores
                .mockResolvedValueOnce({}) // INSERT nuevo token
                .mockResolvedValueOnce({}); // COMMIT

            await generateQRToken(req, res);

            expect(db.query).toHaveBeenCalledWith('COMMIT');
            expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
                token: expect.any(String),
                expiresAt: expect.any(String),
                lockerInfo: { id: 5, numero: 'A-05' }
            }));
        });

        test('CP-03: Debería hacer ROLLBACK si hay error DESPUÉS de iniciar transacción', async () => {
            const mockAssignment = { assignment_id: 10, locker_id: 5, locker_numero: 'A-05' };
            
            db.query
                .mockResolvedValueOnce({ rows: [mockAssignment] }) // Select asignación
                .mockResolvedValueOnce({}) // BEGIN
                .mockRejectedValueOnce(new Error("Error al insertar token")); // Falla el DELETE o INSERT

            await generateQRToken(req, res);

            expect(db.query).toHaveBeenCalledWith('ROLLBACK');
            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Error interno al generar el código QR" });
        });

        test('CP-04: Debería fallar SIN hacer ROLLBACK si el error ocurre ANTES de la transacción', async () => {
            // Forzamos error en la primera consulta (SELECT), transactionStarted sigue en false
            db.query.mockRejectedValueOnce(new Error("Base de datos inalcanzable"));

            await generateQRToken(req, res);

            expect(db.query).not.toHaveBeenCalledWith('ROLLBACK');
            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ mensaje: "Error interno al generar el código QR" });
        });
    });

    // ---------------------------------------------------------
    // 2. Pruebas para validarQRToken
    // ---------------------------------------------------------
    describe('validarQRToken', () => {

        test('CP-05: Debería denegar acceso si el cuerpo viene vacío (Sin código)', async () => {
            req.body = {}; // No hay codigo

            await validarQRToken(req, res);

            expect(db.query).not.toHaveBeenCalled(); // Ni siquiera toca la BD
            expect(res.json).toHaveBeenCalledWith({ acceso: false });
        });

        test('CP-06: Debería denegar acceso si el token Hash no existe en BD', async () => {
            req.body = { codigo: "codigoFalso123" };
            db.query.mockResolvedValueOnce({ rows: [] }); // No encuentra coincidencias

            await validarQRToken(req, res);

            expect(res.json).toHaveBeenCalledWith({ acceso: false });
        });

        test('CP-07: Debería denegar acceso si el token ha expirado', async () => {
            req.body = { codigo: "codigoValidoPeroCaducado" };
            // Creamos una fecha en el pasado (hace 5 minutos)
            const fechaPasada = new Date(Date.now() - 5 * 60 * 1000).toISOString();
            
            db.query.mockResolvedValueOnce({ 
                rows: [{ assignment_id: 1, expires_at: fechaPasada, locker_numero: 'B-02' }] 
            });

            await validarQRToken(req, res);

            expect(res.json).toHaveBeenCalledWith({ acceso: false });
        });

        test('CP-08: Debería conceder acceso, borrar token y devolver número de locker', async () => {
            req.body = { codigo: "codigoPerfecto123" };
            // Creamos una fecha en el futuro (validez activa)
            const fechaFutura = new Date(Date.now() + 5 * 60 * 1000).toISOString();
            
            db.query
                .mockResolvedValueOnce({ 
                    rows: [{ assignment_id: 10, expires_at: fechaFutura, locker_numero: 'C-08' }] 
                }) // Encuentra el token
                .mockResolvedValueOnce({}); // DELETE qr_tokens (Uso único)

            await validarQRToken(req, res);

            expect(db.query).toHaveBeenCalledWith(expect.stringContaining('DELETE'), [10]);
            expect(res.json).toHaveBeenCalledWith({ acceso: true, locker: 'C-08' });
        });

        test('CP-09: Debería manejar fallos de servidor devolviendo acceso falso (Fail-safe)', async () => {
            req.body = { codigo: "codigoTest" };
            db.query.mockRejectedValueOnce(new Error("Fallo crítico de PostgreSQL"));

            await validarQRToken(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith({ acceso: false });
        });
    });
});